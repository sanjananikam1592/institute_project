from django.urls import path
from .views import (
    AdminAPIView,
    TrainerAPIView,
    StudentAPIView,
    # LoginAPIView,
    ChangePasswordAPIView,
    LogoutView,
    # admin_dashboard,
    # trainer_dashboard,
    # student_dashboard,
    CourseAPIView, ModuleAPIView,EnrollmentAPIView,WeekAPIView,
    ScheduleSlotAPIView,
    WeeklyScheduleAPIView,
    TimetableAPIView,
    # TimetablePDFExportAPIView,
             # ← MUST exist in views.py
    WebLoginView,
    APILoginView,
    admin_dashboard,
    trainer_dashboard,
    student_dashboard)
from . import views


urlpatterns = [
    # CRUD APIs
    
    path('admins/', AdminAPIView.as_view()),
    path('admins/<int:admin_id>/', AdminAPIView.as_view()),
    path('trainers/', TrainerAPIView.as_view()),
    path('trainers/<int:trainer_id>/', TrainerAPIView.as_view()),
    path('students/', StudentAPIView.as_view()),
    path('students/<int:student_id>/', StudentAPIView.as_view()),

    # Authentication
    # path('login/', LoginAPIView.as_view(), name='login'),       # Web + API
    path('logout/', LogoutView.as_view(), name='logout'),
    path('change-password/', ChangePasswordAPIView.as_view(), name='change-password'),

    # Dashboards
    # path('admin-dashboard/', admin_dashboard, name='admin_dashboard'),
    # path('trainer-dashboard/', trainer_dashboard, name='trainer_dashboard'),
    # path('student-dashboard/', student_dashboard, name='student_dashboard'),


    ###############################################################################

    path("courses/", CourseAPIView.as_view(), name="course-list"),
    path("courses/<str:course_code>/", CourseAPIView.as_view(), name="course-detail"),


    path('modules/', ModuleAPIView.as_view(), name='module-list-create'),
    path('modules/<str:module_code>/', ModuleAPIView.as_view(), name='module-detail'),


    path('enrollments/', EnrollmentAPIView.as_view(), name='enrollment-list-create'),
    path('enrollments/<uuid:enrollment_id>/', EnrollmentAPIView.as_view(), name='enrollment-detail'),


    # ==============================
    # WEEK URLs
    # ==============================
    path("weeks/",WeekAPIView.as_view(), name="week-list-create"),
    path("weeks/<int:week_id>/",WeekAPIView.as_view(),name="week-detail"),

    # ==============================
    # SCHEDULE SLOT URLs
    # ==============================
    path("schedule-slots/",ScheduleSlotAPIView.as_view(),name="schedule-slot-list-create"),
    path("schedule-slots/<int:slot_id>/",ScheduleSlotAPIView.as_view(),name="schedule-slot-detail"),

    # ==============================
    # WEEKLY SCHEDULE VIEW
    # ==============================
    path("schedule/<int:week_id>/",WeeklyScheduleAPIView.as_view(),name="weekly-schedule"),


    # path("timetable/pdf/", TimetablePDFExportAPIView.as_view(), name="timetable-pdf"),
    path("timetable/",TimetableAPIView.as_view(),name="timetable"),


##########################################################################

    # ---------------------------
    # Web login
    # ---------------------------
    path('login/', WebLoginView.as_view(), name='login'),

    # ---------------------------
    # API login
    # ---------------------------
    path('api/login/', APILoginView.as_view(), name='api-login'),
    path('', views.index_page, name='index'),


    # ---------------------------
    # Dashboards
    # ---------------------------
    path('admin-dashboard/', admin_dashboard, name='admin-dashboard'),
    path('trainer-dashboard/', trainer_dashboard, name='trainer-dashboard'),
    path('student-dashboard/', student_dashboard, name='student-dashboard'),
    

]
