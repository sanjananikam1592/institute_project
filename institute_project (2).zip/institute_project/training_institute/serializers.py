from rest_framework import serializers
from django.db import transaction
from django.contrib.auth import authenticate, get_user_model
from django.core.exceptions import ValidationError

from .models import AdminProfile, TrainerProfile, StudentProfile,Course, Module

from rest_framework import serializers
from django.contrib.auth import password_validation

User = get_user_model()


# =====================================================
# USER BASE SERIALIZER
# =====================================================
class UserSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, min_length=6)

    class Meta:
        model = User
        fields = [
            'username',
            'first_name',
            'last_name',
            'country_code',
            'mobile_number',
            'email',
            'password',
            'role',
            'is_active',
            'is_approved',
            'is_staff',
        ]
        read_only_fields = ['role', 'is_active', 'is_approved', 'is_staff']

    def validate_username(self, value):
        if User.objects.filter(username=value).exists():
            raise serializers.ValidationError("Username already exists")
        return value

    def validate_email(self, value):
        if value and User.objects.filter(email=value).exists():
            raise serializers.ValidationError("Email already exists")
        return value

    def create(self, validated_data):
        password = validated_data.pop('password')
        return User.objects.create_user(password=password, **validated_data)


# =====================================================
# ADMIN PROFILE SERIALIZER (MISSING EARLIER)
# =====================================================
class AdminProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = AdminProfile
        fields = [
            'employee_id',
            'department',
            'designation',
            'office_address',
        ]


# =====================================================
# ADMIN SERIALIZER
# =====================================================
class AdminSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, min_length=6)
    admin_profile = AdminProfileSerializer(write_only=True)

    class Meta:
        model = User
        fields = [
            'username',
            'first_name',
            'last_name',
            'country_code',
            'mobile_number',
            'email',
            'password',
            'admin_profile',
        ]

    @transaction.atomic
    def create(self, validated_data):
        admin_profile_data = validated_data.pop('admin_profile')
        password = validated_data.pop('password')

        user = User.objects.create_user(
            username=validated_data['username'],
            first_name=validated_data.get('first_name', ''),
            last_name=validated_data.get('last_name', ''),
            country_code=validated_data.get('country_code', ''),
            mobile_number=validated_data.get('mobile_number', ''),
            email=validated_data.get('email'),
            role='ADMIN',
            password=password,
        )

        user.is_approved = True
        user.is_staff = True
        user.save()

        AdminProfile.objects.create(user=user, **admin_profile_data)
        return user

    def update(self, instance, validated_data):
        profile_data = validated_data.pop('admin_profile', None)
        password = validated_data.pop('password', None)

        validated_data.pop('role', None)

        for attr, value in validated_data.items():
            setattr(instance, attr, value)

        if password:
            instance.set_password(password)

        instance.save()

        if profile_data:
            profile, _ = AdminProfile.objects.get_or_create(user=instance)
            for attr, value in profile_data.items():
                setattr(profile, attr, value)
            profile.save()

        return instance

class TrainerProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = TrainerProfile
        fields = ['trainer_code', 'specialization', 'qualification', 'experience_years']


class TrainerSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True)
    trainer_profile = TrainerProfileSerializer(write_only=True)

    class Meta:
        model = User
        fields = [
            'id', 'username', 'email', 'first_name', 'last_name',
            'country_code', 'mobile_number', 'password', 'is_approved', 'trainer_profile'
        ]

    @transaction.atomic
    def create(self, validated_data):
        profile_data = validated_data.pop('trainer_profile')
        password = validated_data.pop('password')

        # Create user with all required fields for custom UserManager
        user = User.objects.create_user(
            username=validated_data['username'],
            first_name=validated_data.get('first_name', ''),
            last_name=validated_data.get('last_name', ''),
            country_code=validated_data.get('country_code', ''),
            mobile_number=validated_data.get('mobile_number', ''),
            email=validated_data.get('email', ''),
            role='TRAINER',
            password=password,
        )

        user.is_approved = False
        user.save()

        # Create trainer profile
        TrainerProfile.objects.create(user=user, **profile_data)
        return user

    @transaction.atomic
    def update(self, instance, validated_data):
        profile_data = validated_data.pop('trainer_profile', {})
        password = validated_data.pop('password', None)

        for attr, value in validated_data.items():
            setattr(instance, attr, value)

        if password:
            instance.set_password(password)

        instance.save()

        profile = getattr(instance, 'trainer_profile', None)
        if profile:
            for attr, value in profile_data.items():
                setattr(profile, attr, value)
            profile.save()

        return instance

# =====================================================
# STUDENT SERIALIZER (SAFE VERSION)
# =====================================================


class StudentProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = StudentProfile
        fields = ['enrollment_number', 'course_name', 'batch_year', 'date_of_birth', 'address']


class StudentSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True)
    student_profile = StudentProfileSerializer(write_only=True)
    is_approved = serializers.BooleanField(required=False)  # Admin can toggle approval

    class Meta:
        model = User
        fields = [
            'id', 'username', 'email', 'first_name', 'last_name',
            'country_code', 'mobile_number', 'password', 'is_approved', 'student_profile'
        ]

    @transaction.atomic
    def create(self, validated_data):
        profile_data = validated_data.pop('student_profile')
        password = validated_data.pop('password')

        user = User.objects.create_user(
            username=validated_data['username'],
            first_name=validated_data.get('first_name', ''),
            last_name=validated_data.get('last_name', ''),
            country_code=validated_data.get('country_code', ''),
            mobile_number=validated_data.get('mobile_number', ''),
            email=validated_data.get('email', ''),
            role='STUDENT',
            password=password,
        )

        user.is_approved = False  # Default: student not approved
        user.save()

        StudentProfile.objects.create(user=user, **profile_data)
        return user

    @transaction.atomic
    def update(self, instance, validated_data):
        profile_data = validated_data.pop('student_profile', {})
        password = validated_data.pop('password', None)

        # Admin can toggle approval
        if 'is_approved' in validated_data:
            instance.is_approved = validated_data.pop('is_approved')

        for attr, value in validated_data.items():
            setattr(instance, attr, value)

        if password:
            instance.set_password(password)

        instance.save()

        profile = getattr(instance, 'student_profile', None)
        if profile:
            for attr, value in profile_data.items():
                setattr(profile, attr, value)
            profile.save()

        return instance


# =====================================================
# LOGIN SERIALIZER
# =====================================================
class LoginSerializer(serializers.Serializer):
    username = serializers.CharField()
    password = serializers.CharField(write_only=True)

    def validate(self, data):
        username = data.get('username')
        password = data.get('password')

        user = authenticate(username=username, password=password)

        if not user:
            raise serializers.ValidationError("Invalid username or password")

        # Check if the user is active
        if not user.is_active:
            raise serializers.ValidationError("This account is deactivated")

        # Check if the user is approved
        if not user.is_active:
            raise serializers.ValidationError("User is not approved yet")

        data['user'] = user
        return data




class ChangePasswordSerializer(serializers.Serializer):
    old_password = serializers.CharField(
        write_only=True, 
        required=True, 
        style={'input_type': 'password'}
    )
    new_password = serializers.CharField(
        write_only=True, 
        required=True, 
        style={'input_type': 'password'},
        min_length=6
    )

    def validate_new_password(self, value):
        # Optional: use Django's built-in password validators
        password_validation.validate_password(value)
        return value


class UserManagementSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = [
            "id",
            "username",
            "email",
            "role",
            "is_active",
        ]



##############################################################################

class CourseSerializer(serializers.ModelSerializer):
    total_modules = serializers.IntegerField(read_only=True)
    created_by = serializers.StringRelatedField(read_only=True)

    class Meta:
        model = Course
        fields = [
            "id",
            "course_code",
            "course_name",
            "description",
            "duration_weeks",
            "total_modules",
            "status",
            "is_active",
            "created_by",
            "created_at",
            "updated_at",
        ]
        read_only_fields = [
            "id",
            "total_modules",
            "created_by",
            "created_at",
            "updated_at",
        ]

    # 🔐 Validation
    def validate_course_code(self, value):
        value = value.upper()
        qs = Course.objects.filter(course_code=value)
        if self.instance:
            qs = qs.exclude(pk=self.instance.pk)
        if qs.exists():
            raise serializers.ValidationError("Course code already exists.")
        return value


class ModuleSerializer(serializers.ModelSerializer):
    course_code = serializers.CharField(
        source="course.course_code",
        read_only=True
    )
    course_name = serializers.CharField(
        source="course.course_name",
        read_only=True
    )
    created_by = serializers.StringRelatedField(read_only=True)

    class Meta:
        model = Module
        fields = [
            "id",
            "module_code",
            "module_name",
            "course",
            "course_code",
            "course_name",
            "sequence_no",
            "duration_hours",
            "description",
            "status",
            "is_active",
            "created_by",
            "created_at",
            "updated_at",
        ]
        read_only_fields = [
            "id",
            "course_code",
            "course_name",
            "created_by",
            "created_at",
            "updated_at",
        ]

    # 🔐 Validation
    def validate(self, data):
        module_code = data.get("module_code", "").upper()
        course = data.get("course") or self.instance.course

        qs = Module.objects.filter(
            module_code=module_code,
            course=course
        )
        if self.instance:
            qs = qs.exclude(pk=self.instance.pk)

        if qs.exists():
            raise serializers.ValidationError(
                "This module code already exists for the selected course."
            )

        data["module_code"] = module_code
        return data



from rest_framework import serializers
from .models import Enrollment
from django.contrib.auth import get_user_model
from training_institute.models import Course

User = get_user_model()

class EnrollmentSerializer(serializers.ModelSerializer):
    student_name = serializers.CharField(source='student.get_full_name', read_only=True)
    course_name = serializers.CharField(source='course.course_name', read_only=True)
    
    class Meta:
        model = Enrollment
        fields = [
            "id",
            "student",
            "student_name",
            "course",
            "course_name",
            "status",
            "enrolled_at",
            "updated_at",
            "is_active",
            "grade",
            "created_by",
            "updated_by",
        ]
        read_only_fields = ["id", "enrolled_at", "updated_at", "student_name", "course_name"]

    def validate_grade(self, value):
        """Ensure grade is between 0 and 100."""
        if value is not None and (value < 0 or value > 100):
            raise serializers.ValidationError("Grade must be between 0 and 100.")
        return value

    def validate(self, data):
        """Ensure COMPLETED enrollments are active."""
        status = data.get("status")
        is_active = data.get("is_active", True)
        if status == "COMPLETED" and not is_active:
            raise serializers.ValidationError("Completed enrollments must be active.")
        return data


from rest_framework import serializers
from .models import Week, ScheduleSlot
# from courses.models import Module
# from identity.models import TrainerProfile


class WeekSerializer(serializers.ModelSerializer):

    class Meta:
        model = Week
        fields = [
            "id",
            "week_name",
            "start_date",
            "end_date",
            "is_active",
            "created_at",
            "updated_at",
        ]
        read_only_fields = [
            "id",
            "created_at",
            "updated_at",
        ]

    def validate(self, data):
        """Ensure start_date < end_date"""
        start_date = data.get("start_date")
        end_date = data.get("end_date")

        if start_date and end_date and start_date >= end_date:
            raise serializers.ValidationError(
                "Start date must be before end date."
            )
        return data



class ScheduleSlotSerializer(serializers.ModelSerializer):
    week_name = serializers.CharField(
        source="week.week_name",
        read_only=True
    )

    day_name = serializers.CharField(
        source="get_day_display",
        read_only=True
    )

    status_name = serializers.CharField(
        source="get_status_display",
        read_only=True
    )

    trainer_name = serializers.CharField(
        source="trainer.user.get_full_name",
        read_only=True
    )

    module_name = serializers.CharField(
        source="module.module_name",
        read_only=True
    )

    class Meta:
        model = ScheduleSlot
        fields = [
            "id",
            "week",
            "week_name",
            "day",
            "day_name",
            "start_time",
            "end_time",
            "trainer",
            "trainer_name",
            "module",
            "module_name",
            "status",
            "status_name",
            "remarks",
            "created_at",
            "updated_at",
        ]
        read_only_fields = [
            "id",
            "created_at",
            "updated_at",
            "week_name",
            "day_name",
            "trainer_name",
            "module_name",
            "status_name",
        ]



    def validate(self, data):
        """
        Business validations:
        - start_time < end_time
        - ALLOCATED slots require trainer & module
        - Only ACTIVE modules allowed
        """

        start_time = data.get("start_time")
        end_time = data.get("end_time")
        status = data.get("status", "FREE")
        trainer = data.get("trainer")
        module = data.get("module")

        # Time validation
        if start_time and end_time and start_time >= end_time:
            raise serializers.ValidationError(
                "Start time must be before end time."
            )

        # Allocation rule
        if status == "ALLOCATED":
            if not trainer or not module:
                raise serializers.ValidationError(
                    "Trainer and Module are required for allocated slot."
                )

        # Module status validation
        if module and module.status != "ACTIVE":
            raise serializers.ValidationError(
                "Only ACTIVE modules can be scheduled."
            )

        return data


class WeekScheduleSerializer(serializers.ModelSerializer):
    slots = ScheduleSlotSerializer(many=True, read_only=True)

    class Meta:
        model = Week
        fields = [
            "id",
            "week_name",
            "start_date",
            "end_date",
            "is_active",
            "slots",
        ]



# ===============================
# WeekSchedule Serializer (Full Timetable)
# ===============================
class WeekScheduleSerializer(serializers.ModelSerializer):
    slots = ScheduleSlotSerializer(many=True, read_only=True)  # Nested slots

    class Meta:
        model = Week
        fields = ["id", "week_name", "start_date", "end_date", "is_active", "slots"]
        read_only_fields = ["id", "slots"]

    def validate(self, data):
        start_date = data.get("start_date")
        end_date = data.get("end_date")
        if start_date and end_date and start_date >= end_date:
            raise serializers.ValidationError("Start date must be before end date.")
        return data


        