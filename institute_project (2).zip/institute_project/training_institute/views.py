# =====================================================
# Django Imports
# =====================================================
from django.shortcuts import render, redirect, get_object_or_404
from django.utils import timezone
from django.contrib.auth import authenticate, login, logout as django_logout, get_user_model
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.utils.encoding import force_bytes
from django.contrib.auth.tokens import default_token_generator
from django.core.mail import send_mail
from django.db import IntegrityError
from django.contrib.auth.decorators import login_required
from django.views import View
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse

# =====================================================
# DRF Imports
# =====================================================
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status, serializers
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.renderers import JSONRenderer, TemplateHTMLRenderer

# =====================================================
# JWT Imports
# =====================================================
from rest_framework_simplejwt.tokens import RefreshToken

# =====================================================
# App Imports
# =====================================================
from .models import User, AdminProfile, TrainerProfile, StudentProfile
from .serializers import (
    AdminSerializer,
    TrainerSerializer,
    StudentSerializer,
    LoginSerializer,
    ChangePasswordSerializer
)

from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required




from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import AllowAny
from rest_framework import status
from django.contrib.auth import authenticate
from rest_framework_simplejwt.tokens import RefreshToken
from .serializers import LoginSerializer  # Make sure this exists


def index_page(request):
    return render(request, 'index.html')

class WebLoginView(View):
    def get(self, request):
        return render(request, "login.html")

    def post(self, request):
        username = request.POST.get("username")
        password = request.POST.get("password")

        if not username or not password:
            return render(request, "login.html", {"error": "Username and password are required"})

        user = authenticate(username=username, password=password)
        if not user:
            return render(request, "login.html", {"error": "Invalid credentials"})

        if not user.is_active:
            return render(request, "login.html", {"error": "Your account is inactive. Contact admin."})

        # Role-based redirect
        role = user.role.upper()
        login(request, user)  # Create session

        if role == "ADMIN":
            return redirect("/admin-dashboard/")
        elif role == "TRAINER":
            return redirect("/trainer-dashboard/")
        elif role == "STUDENT":
            return redirect("/student-dashboard/")
        else:
            return render(request, "login.html", {"error": "User role is not recognized"})


class APILoginView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        if not serializer.is_valid():
            return Response({
                "status": "error",
                "message": "Invalid data",
                "errors": serializer.errors
            }, status=status.HTTP_400_BAD_REQUEST)

        username = serializer.validated_data.get("username")
        password = serializer.validated_data.get("password")

        user = authenticate(username=username, password=password)
        if not user:
            return Response({"status": "error", "message": "Invalid credentials"}, status=status.HTTP_401_UNAUTHORIZED)

        if not user.is_active:
            return Response({"status": "error", "message": "User account is inactive"}, status=status.HTTP_403_FORBIDDEN)

        # Role-based dashboard
        role = user.role.upper()
        if role == "ADMIN":
            dashboard_url = "/admin-dashboard/"
        elif role == "TRAINER":
            dashboard_url = "/trainer-dashboard/"
        elif role == "STUDENT":
            dashboard_url = "/student-dashboard/"
        else:
            return Response({"status": "error", "message": "User role is not recognized"}, status=status.HTTP_403_FORBIDDEN)

        # JWT tokens
        refresh = RefreshToken.for_user(user)
        return Response({
            "status": "success",
            "message": "Login successful",
            "role": user.role,
            "dashboard": dashboard_url,
            "tokens": {
                "access": str(refresh.access_token),
                "refresh": str(refresh)
            },
            "user": {
                "id": user.id,
                "username": user.username,
                "email": user.email,
                "first_name": user.first_name,
                "last_name": user.last_name
            }
        }, status=status.HTTP_200_OK)



@login_required
def admin_dashboard(request):
    return render(request, "admin_dashboard.html")

@login_required
def trainer_dashboard(request):
    return render(request, "trainer_dashboard.html")

@login_required
def student_dashboard(request):
    return render(request, "student_dashboard.html")


# =====================================================
# LOGOUT VIEW
# URL: /auth/logout/
# =====================================================
class LogoutView(APIView):
    permission_classes = [AllowAny]

    def post(self, request, *args, **kwargs):
        """
        Handles both:
        - API logout (blacklist JWT refresh token)
        - Web logout (clear session)
        """
        is_api_request = request.content_type == "application/json"

        if is_api_request:
            # API logout with refresh token
            try:
                refresh_token = request.data.get("refresh")
                if not refresh_token:
                    return Response(
                        {"detail": "Refresh token required"},
                        status=status.HTTP_400_BAD_REQUEST
                    )

                token = RefreshToken(refresh_token)
                token.blacklist()  # Blacklist the refresh token

                return Response(
                    {"detail": "Logout successful"},
                    status=status.HTTP_205_RESET_CONTENT
                )

            except Exception as e:
                return Response(
                    {"error": str(e)},
                    status=status.HTTP_400_BAD_REQUEST
                )

        else:
            # Web logout: clear session and show message
            django_logout(request)
            messages.success(request, "You have been logged out successfully.")
            return redirect('/login/')

    def get(self, request, *args, **kwargs):
        """
        Optional: allow GET logout for web users (redirect to login)
        """
        django_logout(request)
        messages.success(request, "You have been logged out successfully.")
        return redirect('/login/')

# =====================================================
# CHANGE PASSWORD
# URL: /auth/change-password/
# =====================================================

class ChangePasswordAPIView(APIView):
    permission_classes = [AllowAny]  # Only logged-in users can change password

    def get(self, request, *args, **kwargs):
        """
        Render change password form for web users.
        """
        return render(request, "change_password.html")

    def post(self, request, *args, **kwargs):
        """
        Handle password change for both API and web requests.
        """
        # Detect API request (JSON) vs Web (form)
        is_api_request = request.content_type == "application/json"

        if is_api_request:
            serializer = ChangePasswordSerializer(data=request.data)
        else:
            serializer = ChangePasswordSerializer(data=request.POST)

        serializer.is_valid(raise_exception=True)

        user = request.user
        old_password = serializer.validated_data['old_password']
        new_password = serializer.validated_data['new_password']

        # Check old password
        if not user.check_password(old_password):
            if is_api_request:
                return Response(
                    {"status": "error", "message": "Old password is incorrect"},
                    status=status.HTTP_400_BAD_REQUEST
                )
            else:
                return render(request, "change_password.html", {"error": "Old password is incorrect"})

        # Set new password
        user.set_password(new_password)
        user.save()

        # Logout user for security
        if not is_api_request:
            logout(request)
            messages.success(request, "Password changed successfully. Please login again.")
            return redirect('/login/')

        return Response(
            {"status": "success", "message": "Password changed successfully"},
            status=status.HTTP_200_OK
        )


















class AdminAPIView(APIView):
    """
    Admin CRUD API (Username-based)
    Supports both Postman (JSON) and browser (HTML)
    All operations are public (AllowAny)
    """
    renderer_classes = [JSONRenderer, TemplateHTMLRenderer]
    template_name = "admin_list.html"  # Template for listing admins
    form_template_name = "admin_form.html"  # Template for creating/updating admin
    permission_classes = [AllowAny]  # All CRUD operations public

    # =====================================================
    # CREATE ADMIN
    # =====================================================
    def post(self, request, format=None):
        serializer = AdminSerializer(data=request.data)

        if not serializer.is_valid():
            if request.accepted_renderer.format == "html":
                return Response({"form_errors": serializer.errors}, template_name=self.form_template_name)
            return Response(
                {"status": "error", "message": "Invalid input", "errors": serializer.errors},
                status=status.HTTP_400_BAD_REQUEST
            )

        try:
            serializer.save()
        except IntegrityError:
            message = "Username or email already exists"
            if request.accepted_renderer.format == "html":
                return Response({"form_errors": {"__all__": message}}, template_name=self.form_template_name)
            return Response({"status": "error", "message": message}, status=status.HTTP_409_CONFLICT)
        except Exception as e:
            return Response(
                {"status": "error", "message": "Server error", "errors": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

        if request.accepted_renderer.format == "html":
            return Response({"success_message": "Admin created successfully"}, template_name=self.form_template_name)

        return Response(
            {"status": "success", "message": "Admin created successfully", "data": serializer.data},
            status=status.HTTP_201_CREATED
        )

    # =====================================================
    # LIST ADMINS / GET ADMIN BY USERNAME
    # =====================================================
    def get(self, request, username=None, format=None):
        try:
            if username:
                admin = get_object_or_404(User, username=username, role='ADMIN')
                serializer = AdminSerializer(admin)
                data = serializer.data
            else:
                admins = User.objects.filter(role='ADMIN')
                serializer = AdminSerializer(admins, many=True)
                data = serializer.data

            if request.accepted_renderer.format == "html":
                return Response({"admins": data}, template_name=self.template_name)

            return Response({"status": "success", "data": data}, status=status.HTTP_200_OK)

        except Exception as e:
            return Response(
                {"status": "error", "message": "Server error", "errors": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    # =====================================================
    # UPDATE ADMIN
    # =====================================================
    def put(self, request, username, format=None):
        try:
            admin = get_object_or_404(User, username=username, role='ADMIN')

            # Prevent username change
            if 'username' in request.data and request.data['username'] != username:
                return Response(
                    {"status": "error", "message": "Username cannot be changed"},
                    status=status.HTTP_400_BAD_REQUEST
                )

            serializer = AdminSerializer(admin, data=request.data, partial=True)
            if not serializer.is_valid():
                if request.accepted_renderer.format == "html":
                    return Response({"form_errors": serializer.errors}, template_name=self.form_template_name)
                return Response(
                    {"status": "error", "message": "Invalid input", "errors": serializer.errors},
                    status=status.HTTP_400_BAD_REQUEST
                )

            serializer.save()
            if request.accepted_renderer.format == "html":
                return Response({"success_message": "Admin updated successfully"}, template_name=self.form_template_name)

            return Response(
                {"status": "success", "message": "Admin updated successfully", "data": serializer.data},
                status=status.HTTP_200_OK
            )

        except Exception as e:
            return Response(
                {"status": "error", "message": "Server error", "errors": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    # =====================================================
    # DELETE ADMIN
    # =====================================================
    def delete(self, request, username, format=None):
        try:
            admin = get_object_or_404(User, username=username, role='ADMIN')
            admin.delete()
            return Response(
                {"status": "success", "message": "Admin deleted successfully"},
                status=status.HTTP_200_OK
            )
        except Exception as e:
            return Response(
                {"status": "error", "message": "Server error", "errors": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

# =====================================================
# Trainer API View
# =====================================================

class TrainerAPIView(APIView):
    """
    Trainer CRUD API (ID-based)
    Supports both Postman (JSON) and browser (HTML)
    All operations are public (AllowAny)
    """
    renderer_classes = [JSONRenderer, TemplateHTMLRenderer]
    template_name = "trainer_list.html"  # For listing trainers
    form_template_name = "trainer_form.html"  # For create/update form
    permission_classes = [AllowAny]  # All operations public

    # =====================================================
    # CREATE TRAINER
    # =====================================================
    def post(self, request, format=None):
        serializer = TrainerSerializer(data=request.data)
        if not serializer.is_valid():
            if request.accepted_renderer.format == "html":
                return Response({"form_errors": serializer.errors}, template_name=self.form_template_name)
            return Response({"status": "error", "message": "Invalid input", "errors": serializer.errors},
                            status=status.HTTP_400_BAD_REQUEST)
        try:
            serializer.save()
        except IntegrityError:
            message = "Username or email already exists"
            if request.accepted_renderer.format == "html":
                return Response({"form_errors": {"__all__": message}}, template_name=self.form_template_name)
            return Response({"status": "error", "message": message}, status=status.HTTP_409_CONFLICT)
        except Exception as e:
            return Response({"status": "error", "message": "Server error", "errors": str(e)},
                            status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        if request.accepted_renderer.format == "html":
            return Response({"success_message": "Trainer created successfully"}, template_name=self.form_template_name)

        return Response({"status": "success", "message": "Trainer created successfully", "data": serializer.data},
                        status=status.HTTP_201_CREATED)

    # =====================================================
    # LIST TRAINERS / GET TRAINER BY ID
    # =====================================================
    def get(self, request, trainer_id=None, format=None):
        try:
            if trainer_id:
                trainer = get_object_or_404(User, id=trainer_id, role='TRAINER')
                serializer = TrainerSerializer(trainer)
                data = serializer.data
            else:
                trainers = User.objects.filter(role='TRAINER')
                serializer = TrainerSerializer(trainers, many=True)
                data = serializer.data

            if request.accepted_renderer.format == "html":
                return Response({"trainers": data}, template_name=self.template_name)

            return Response({"status": "success", "data": data}, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({"status": "error", "message": "Server error", "errors": str(e)},
                            status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    # =====================================================
    # UPDATE TRAINER
    # =====================================================
    def put(self, request, trainer_id, format=None):
        trainer = get_object_or_404(User, id=trainer_id, role='TRAINER')
        serializer = TrainerSerializer(trainer, data=request.data, partial=True)
        if not serializer.is_valid():
            if request.accepted_renderer.format == "html":
                return Response({"form_errors": serializer.errors}, template_name=self.form_template_name)
            return Response({"status": "error", "message": "Invalid input", "errors": serializer.errors},
                            status=status.HTTP_400_BAD_REQUEST)
        try:
            serializer.save()
        except Exception as e:
            return Response({"status": "error", "message": "Server error", "errors": str(e)},
                            status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        if request.accepted_renderer.format == "html":
            return Response({"success_message": "Trainer updated successfully"}, template_name=self.form_template_name)

        return Response({"status": "success", "message": "Trainer updated successfully", "data": serializer.data},
                        status=status.HTTP_200_OK)

    # =====================================================
    # DELETE TRAINER
    # =====================================================
    def delete(self, request, trainer_id, format=None):
        trainer = get_object_or_404(User, id=trainer_id, role='TRAINER')
        try:
            trainer.delete()
        except Exception as e:
            return Response({"status": "error", "message": "Server error", "errors": str(e)},
                            status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        return Response({"status": "success", "message": "Trainer deleted successfully"},
                        status=status.HTTP_200_OK)

# =====================================================
# Student API View
# =====================================================


class StudentAPIView(APIView):
    """
    Student CRUD API (ID-based)
    Supports both Postman (JSON) and browser (HTML)
    All operations are public (AllowAny)
    """
    renderer_classes = [JSONRenderer, TemplateHTMLRenderer]
    template_name = "student_list.html"  # For listing students
    form_template_name = "student_form.html"  # For create/update form
    permission_classes = [AllowAny]  # All operations public

    # =====================================================
    # CREATE STUDENT
    # =====================================================
    def post(self, request, format=None):
        serializer = StudentSerializer(data=request.data)
        if not serializer.is_valid():
            if request.accepted_renderer.format == "html":
                return Response({"form_errors": serializer.errors}, template_name=self.form_template_name)
            return Response({"status": "error", "message": "Invalid input", "errors": serializer.errors},
                            status=status.HTTP_400_BAD_REQUEST)
        try:
            serializer.save()
        except IntegrityError:
            message = "Username or email already exists"
            if request.accepted_renderer.format == "html":
                return Response({"form_errors": {"__all__": message}}, template_name=self.form_template_name)
            return Response({"status": "error", "message": message}, status=status.HTTP_409_CONFLICT)
        except Exception as e:
            return Response({"status": "error", "message": "Server error", "errors": str(e)},
                            status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        if request.accepted_renderer.format == "html":
            return Response({"success_message": "Student created successfully"}, template_name=self.form_template_name)

        return Response({"status": "success", "message": "Student created successfully", "data": serializer.data},
                        status=status.HTTP_201_CREATED)

    # =====================================================
    # LIST STUDENTS / GET STUDENT BY ID
    # =====================================================
    def get(self, request, student_id=None, format=None):
        try:
            if student_id:
                student = get_object_or_404(User, id=student_id, role='STUDENT')
                serializer = StudentSerializer(student)
                data = serializer.data
            else:
                students = User.objects.filter(role='STUDENT')
                serializer = StudentSerializer(students, many=True)
                data = serializer.data

            if request.accepted_renderer.format == "html":
                return Response({"students": data}, template_name=self.template_name)

            return Response({"status": "success", "data": data}, status=status.HTTP_200_OK)

        except Exception as e:
            return Response({"status": "error", "message": "Server error", "errors": str(e)},
                            status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    # =====================================================
    # UPDATE STUDENT
    # =====================================================
    def put(self, request, student_id, format=None):
        student = get_object_or_404(User, id=student_id, role='STUDENT')
        serializer = StudentSerializer(student, data=request.data, partial=True)
        if not serializer.is_valid():
            if request.accepted_renderer.format == "html":
                return Response({"form_errors": serializer.errors}, template_name=self.form_template_name)
            return Response({"status": "error", "message": "Invalid input", "errors": serializer.errors},
                            status=status.HTTP_400_BAD_REQUEST)
        try:
            serializer.save()
        except Exception as e:
            return Response({"status": "error", "message": "Server error", "errors": str(e)},
                            status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        if request.accepted_renderer.format == "html":
            return Response({"success_message": "Student updated successfully"}, template_name=self.form_template_name)

        return Response({"status": "success", "message": "Student updated successfully", "data": serializer.data},
                        status=status.HTTP_200_OK)

    # =====================================================
    # DELETE STUDENT
    # =====================================================
    def delete(self, request, student_id, format=None):
        student = get_object_or_404(User, id=student_id, role='STUDENT')
        try:
            student.delete()
        except Exception as e:
            return Response({"status": "error", "message": "Server error", "errors": str(e)},
                            status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        return Response({"status": "success", "message": "Student deleted successfully"},
                        status=status.HTTP_200_OK)










#############################################################################################

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.renderers import JSONRenderer, TemplateHTMLRenderer
from django.shortcuts import get_object_or_404
from django.db import IntegrityError

from .models import Course
from .serializers import CourseSerializer
from .permissions import IsAdminOrReadOnly


class CourseAPIView(APIView):
    """
    COURSE CRUD API

    Admin:
        ✔ Create
        ✔ Update
        ✔ Delete
        ✔ Get
        ✔ Get All

    Trainer & Student:
        ✔ Get
        ✔ Get All (Student → only enrolled courses)
    """

    renderer_classes = [JSONRenderer, TemplateHTMLRenderer]
    template_name = "course_list.html"
    form_template_name = "course_form.html"
    permission_classes = [IsAdminOrReadOnly]

    # =====================================================
    # CREATE COURSE (ADMIN ONLY)
    # =====================================================
    def post(self, request, format=None):
        serializer = CourseSerializer(data=request.data)

        if not serializer.is_valid():
            if request.accepted_renderer.format == "html":
                return Response(
                    {"form_errors": serializer.errors},
                    template_name=self.form_template_name
                )
            return Response(
                {"status": "error", "errors": serializer.errors},
                status=status.HTTP_400_BAD_REQUEST
            )

        try:
            serializer.save(created_by=request.user)
        except IntegrityError:
            message = "Course code already exists"
            if request.accepted_renderer.format == "html":
                return Response(
                    {"form_errors": {"__all__": message}},
                    template_name=self.form_template_name
                )
            return Response(
                {"status": "error", "message": message},
                status=status.HTTP_409_CONFLICT
            )

        if request.accepted_renderer.format == "html":
            return Response(
                {"success_message": "Course created successfully"},
                template_name=self.form_template_name
            )

        return Response(
            {"status": "success", "data": serializer.data},
            status=status.HTTP_201_CREATED
        )

    # =====================================================
    # LIST COURSES / GET COURSE BY CODE
    # =====================================================
    def get(self, request, course_code=None, format=None):
        user = request.user

        if course_code:
            course = get_object_or_404(Course, course_code=course_code)
            serializer = CourseSerializer(course)
            data = serializer.data
        else:
            # Admin & Trainer → all courses
            if user.groups.filter(name__in=["Admin", "Trainer"]).exists():
                courses = Course.objects.all()
            else:
                # Student → enrolled courses only
                from .models import Enrollment
                enrolled_ids = Enrollment.objects.filter(
                    student=user
                ).values_list("course_id", flat=True)
                courses = Course.objects.filter(id__in=enrolled_ids)

            serializer = CourseSerializer(courses, many=True)
            data = serializer.data

        if request.accepted_renderer.format == "html":
            return Response(
                {"courses": data},
                template_name=self.template_name
            )

        return Response(
            {"status": "success", "data": data},
            status=status.HTTP_200_OK
        )

    # =====================================================
    # UPDATE COURSE (ADMIN ONLY)
    # =====================================================
    def put(self, request, course_code, format=None):
        course = get_object_or_404(Course, course_code=course_code)

        serializer = CourseSerializer(course, data=request.data, partial=True)

        if not serializer.is_valid():
            if request.accepted_renderer.format == "html":
                return Response(
                    {"form_errors": serializer.errors},
                    template_name=self.form_template_name
                )
            return Response(
                {"status": "error", "errors": serializer.errors},
                status=status.HTTP_400_BAD_REQUEST
            )

        serializer.save()

        if request.accepted_renderer.format == "html":
            return Response(
                {"success_message": "Course updated successfully"},
                template_name=self.form_template_name
            )

        return Response(
            {"status": "success", "data": serializer.data},
            status=status.HTTP_200_OK
        )

    # =====================================================
    # DELETE COURSE (ADMIN ONLY)
    # =====================================================
    def delete(self, request, course_code, format=None):
        course = get_object_or_404(Course, course_code=course_code)
        course.delete()

        return Response(
            {"status": "success", "message": "Course deleted successfully"},
            status=status.HTTP_200_OK
        )



from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.renderers import JSONRenderer, TemplateHTMLRenderer
from django.shortcuts import get_object_or_404
from django.db import IntegrityError

from .models import Module, Course
from .serializers import ModuleSerializer
from .permissions import IsAdminOrReadOnly


class ModuleAPIView(APIView):
    """
    MODULE CRUD API

    Admin:
        ✔ Create
        ✔ Update
        ✔ Delete
        ✔ Get
        ✔ Get All

    Trainer & Student:
        ✔ Get
        ✔ Get All (Student → only enrolled courses)
    """

    renderer_classes = [JSONRenderer, TemplateHTMLRenderer]
    template_name = "module_list.html"
    form_template_name = "module_form.html"
    permission_classes = [IsAdminOrReadOnly]

    # =====================================================
    # CREATE MODULE (ADMIN ONLY)
    # =====================================================
    def post(self, request, format=None):
        serializer = ModuleSerializer(data=request.data)

        if not serializer.is_valid():
            if request.accepted_renderer.format == "html":
                return Response(
                    {"form_errors": serializer.errors},
                    template_name=self.form_template_name
                )
            return Response(
                {"status": "error", "errors": serializer.errors},
                status=status.HTTP_400_BAD_REQUEST
            )

        try:
            serializer.save(created_by=request.user)
        except IntegrityError:
            message = "Module code already exists for this course"
            if request.accepted_renderer.format == "html":
                return Response(
                    {"form_errors": {"__all__": message}},
                    template_name=self.form_template_name
                )
            return Response(
                {"status": "error", "message": message},
                status=status.HTTP_409_CONFLICT
            )

        if request.accepted_renderer.format == "html":
            return Response(
                {"success_message": "Module created successfully"},
                template_name=self.form_template_name
            )

        return Response(
            {"status": "success", "data": serializer.data},
            status=status.HTTP_201_CREATED
        )

    # =====================================================
    # LIST MODULES / GET MODULE BY CODE
    # =====================================================
    def get(self, request, module_code=None, format=None):
        user = request.user

        if module_code:
            module = get_object_or_404(Module, module_code=module_code)
            serializer = ModuleSerializer(module)
            data = serializer.data
        else:
            # Admin & Trainer → all modules
            if user.groups.filter(name__in=["Admin", "Trainer"]).exists():
                modules = Module.objects.all()
            else:
                # Student → only modules from enrolled courses
                from .models import Enrollment
                enrolled_course_ids = Enrollment.objects.filter(
                    student=user
                ).values_list("course_id", flat=True)
                modules = Module.objects.filter(course_id__in=enrolled_course_ids)

            serializer = ModuleSerializer(modules, many=True)
            data = serializer.data

        if request.accepted_renderer.format == "html":
            return Response(
                {"modules": data},
                template_name=self.template_name
            )

        return Response(
            {"status": "success", "data": data},
            status=status.HTTP_200_OK
        )

    # =====================================================
    # UPDATE MODULE (ADMIN ONLY)
    # =====================================================
    def put(self, request, module_code, format=None):
        module = get_object_or_404(Module, module_code=module_code)
        serializer = ModuleSerializer(module, data=request.data, partial=True)

        if not serializer.is_valid():
            if request.accepted_renderer.format == "html":
                return Response(
                    {"form_errors": serializer.errors},
                    template_name=self.form_template_name
                )
            return Response(
                {"status": "error", "errors": serializer.errors},
                status=status.HTTP_400_BAD_REQUEST
            )

        serializer.save()

        if request.accepted_renderer.format == "html":
            return Response(
                {"success_message": "Module updated successfully"},
                template_name=self.form_template_name
            )

        return Response(
            {"status": "success", "data": serializer.data},
            status=status.HTTP_200_OK
        )

    # =====================================================
    # DELETE MODULE (ADMIN ONLY)
    # =====================================================
    def delete(self, request, module_code, format=None):
        module = get_object_or_404(Module, module_code=module_code)
        module.delete()

        return Response(
            {"status": "success", "message": "Module deleted successfully"},
            status=status.HTTP_200_OK
        )



from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.renderers import JSONRenderer, TemplateHTMLRenderer
from django.shortcuts import get_object_or_404
from django.db import IntegrityError

from .models import Enrollment
from .serializers import EnrollmentSerializer
from .permissions import IsAdminOrReadOnly  # Use your permission class
from django.contrib.auth import get_user_model

User = get_user_model()


class EnrollmentAPIView(APIView):
    """
    ENROLLMENT CRUD API

    Admin:
        ✔ Create
        ✔ Update
        ✔ Delete
        ✔ Get
        ✔ Get All

    Trainer & Student:
        ✔ Get
        ✔ Get All (Student → only own enrollments)
    """

    renderer_classes = [JSONRenderer, TemplateHTMLRenderer]
    template_name = "enrollment_list.html"
    form_template_name = "enrollment_form.html"
    permission_classes = [IsAdminOrReadOnly]

    # =====================================================
    # CREATE ENROLLMENT (ADMIN ONLY)
    # =====================================================
    def post(self, request, format=None):
        serializer = EnrollmentSerializer(data=request.data)

        if not serializer.is_valid():
            if request.accepted_renderer.format == "html":
                return Response(
                    {"form_errors": serializer.errors},
                    template_name=self.form_template_name
                )
            return Response(
                {"status": "error", "errors": serializer.errors},
                status=status.HTTP_400_BAD_REQUEST
            )

        try:
            serializer.save(created_by=request.user)
        except IntegrityError:
            message = "Student is already enrolled in this course"
            if request.accepted_renderer.format == "html":
                return Response(
                    {"form_errors": {"__all__": message}},
                    template_name=self.form_template_name
                )
            return Response(
                {"status": "error", "message": message},
                status=status.HTTP_409_CONFLICT
            )

        if request.accepted_renderer.format == "html":
            return Response(
                {"success_message": "Enrollment created successfully"},
                template_name=self.form_template_name
            )

        return Response(
            {"status": "success", "data": serializer.data},
            status=status.HTTP_201_CREATED
        )

    # =====================================================
    # LIST ENROLLMENTS / GET ENROLLMENT BY ID
    # =====================================================
    def get(self, request, enrollment_id=None, format=None):
        user = request.user

        if enrollment_id:
            enrollment = get_object_or_404(Enrollment, id=enrollment_id)
            serializer = EnrollmentSerializer(enrollment)
            data = serializer.data
        else:
            # Admin & Trainer → all enrollments
            if user.groups.filter(name__in=["Admin", "Trainer"]).exists():
                enrollments = Enrollment.objects.all()
            else:
                # Student → own enrollments only
                enrollments = Enrollment.objects.filter(student=user)

            serializer = EnrollmentSerializer(enrollments, many=True)
            data = serializer.data

        if request.accepted_renderer.format == "html":
            return Response(
                {"enrollments": data},
                template_name=self.template_name
            )

        return Response(
            {"status": "success", "data": data},
            status=status.HTTP_200_OK
        )

    # =====================================================
    # UPDATE ENROLLMENT (ADMIN ONLY)
    # =====================================================
    def put(self, request, enrollment_id, format=None):
        enrollment = get_object_or_404(Enrollment, id=enrollment_id)

        serializer = EnrollmentSerializer(enrollment, data=request.data, partial=True)

        if not serializer.is_valid():
            if request.accepted_renderer.format == "html":
                return Response(
                    {"form_errors": serializer.errors},
                    template_name=self.form_template_name
                )
            return Response(
                {"status": "error", "errors": serializer.errors},
                status=status.HTTP_400_BAD_REQUEST
            )

        serializer.save(updated_by=request.user)

        if request.accepted_renderer.format == "html":
            return Response(
                {"success_message": "Enrollment updated successfully"},
                template_name=self.form_template_name
            )

        return Response(
            {"status": "success", "data": serializer.data},
            status=status.HTTP_200_OK
        )

    # =====================================================
    # DELETE ENROLLMENT (ADMIN ONLY)
    # =====================================================
    def delete(self, request, enrollment_id, format=None):
        enrollment = get_object_or_404(Enrollment, id=enrollment_id)
        enrollment.delete()

        return Response(
            {"status": "success", "message": "Enrollment deleted successfully"},
            status=status.HTTP_200_OK
        )





from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.renderers import JSONRenderer, TemplateHTMLRenderer
from django.shortcuts import get_object_or_404
from django.db import IntegrityError

from .models import Week, ScheduleSlot
from .serializers import (
    WeekSerializer,
    ScheduleSlotSerializer,
    WeekScheduleSerializer
)
from .permissions import IsAdminOrReadOnly



class WeekAPIView(APIView):
    """
    WEEK CRUD API

    Admin:
        ✔ Create
        ✔ Update
        ✔ Delete
        ✔ Get
        ✔ Get All

    Others:
        ✔ Get
        ✔ Get All
    """

    renderer_classes = [JSONRenderer, TemplateHTMLRenderer]
    template_name = "week_list.html"
    form_template_name = "week_form.html"
    permission_classes = [IsAdminOrReadOnly]

    # ===============================
    # CREATE WEEK (ADMIN)
    # ===============================
    def post(self, request, format=None):
        serializer = WeekSerializer(data=request.data)

        if not serializer.is_valid():
            return Response(
                {"form_errors": serializer.errors},
                template_name=self.form_template_name
            )

        try:
            serializer.save()
        except IntegrityError:
            return Response(
                {"form_errors": {"week_name": "Week already exists"}},
                template_name=self.form_template_name
            )

        return Response(
            {"success_message": "Week created successfully"},
            template_name=self.form_template_name
        )

    # ===============================
    # GET / LIST WEEKS
    # ===============================
    def get(self, request, week_id=None, format=None):
        if week_id:
            week = get_object_or_404(Week, id=week_id)
            serializer = WeekSerializer(week)
            data = serializer.data
        else:
            weeks = Week.objects.all()
            serializer = WeekSerializer(weeks, many=True)
            data = serializer.data

        if request.accepted_renderer.format == "html":
            return Response(
                {"weeks": data},
                template_name=self.template_name
            )

        return Response(
            {"status": "success", "data": data},
            status=status.HTTP_200_OK
        )

    # ===============================
    # UPDATE WEEK (ADMIN)
    # ===============================
    def put(self, request, week_id, format=None):
        week = get_object_or_404(Week, id=week_id)
        serializer = WeekSerializer(week, data=request.data, partial=True)

        if not serializer.is_valid():
            return Response(
                {"form_errors": serializer.errors},
                template_name=self.form_template_name
            )

        serializer.save()

        return Response(
            {"success_message": "Week updated successfully"},
            template_name=self.form_template_name
        )

    # ===============================
    # DELETE WEEK (ADMIN)
    # ===============================
    def delete(self, request, week_id, format=None):
        week = get_object_or_404(Week, id=week_id)
        week.delete()

        return Response(
            {"status": "success", "message": "Week deleted successfully"},
            status=status.HTTP_200_OK
        )



class ScheduleSlotAPIView(APIView):
    """
    SCHEDULE SLOT CRUD API

    Admin:
        ✔ Create
        ✔ Update
        ✔ Delete
        ✔ Get
        ✔ Get All

    Others:
        ✔ Get
    """

    renderer_classes = [JSONRenderer, TemplateHTMLRenderer]
    template_name = "schedule_list.html"
    form_template_name = "schedule_form.html"
    permission_classes = [IsAdminOrReadOnly]

    # ===============================
    # CREATE SLOT (ADMIN)
    # ===============================
    def post(self, request, format=None):
        serializer = ScheduleSlotSerializer(data=request.data)

        if not serializer.is_valid():
            return Response(
                {"form_errors": serializer.errors},
                template_name=self.form_template_name
            )

        try:
            serializer.save()
        except IntegrityError:
            return Response(
                {"form_errors": {"__all__": "Slot already exists"}},
                template_name=self.form_template_name
            )

        return Response(
            {"success_message": "Schedule slot created successfully"},
            template_name=self.form_template_name
        )

    # ===============================
    # GET / LIST SLOTS
    # ===============================
    def get(self, request, slot_id=None, format=None):
        if slot_id:
            slot = get_object_or_404(ScheduleSlot, id=slot_id)
            serializer = ScheduleSlotSerializer(slot)
            data = serializer.data
        else:
            slots = ScheduleSlot.objects.select_related(
                "week", "trainer", "module"
            )
            serializer = ScheduleSlotSerializer(slots, many=True)
            data = serializer.data

        if request.accepted_renderer.format == "html":
            return Response(
                {"slots": data},
                template_name=self.template_name
            )

        return Response(
            {"status": "success", "data": data},
            status=status.HTTP_200_OK
        )

    # ===============================
    # UPDATE SLOT (ADMIN)
    # ===============================
    def put(self, request, slot_id, format=None):
        slot = get_object_or_404(ScheduleSlot, id=slot_id)
        serializer = ScheduleSlotSerializer(
            slot,
            data=request.data,
            partial=True
        )

        if not serializer.is_valid():
            return Response(
                {"form_errors": serializer.errors},
                template_name=self.form_template_name
            )

        serializer.save()

        return Response(
            {"success_message": "Schedule slot updated successfully"},
            template_name=self.form_template_name
        )

    # ===============================
    # DELETE SLOT (ADMIN)
    # ===============================
    def delete(self, request, slot_id, format=None):
        slot = get_object_or_404(ScheduleSlot, id=slot_id)
        slot.delete()

        return Response(
            {"status": "success", "message": "Schedule slot deleted successfully"},
            status=status.HTTP_200_OK
        )



class WeeklyScheduleAPIView(APIView):
    """
    GET FULL WEEK SCHEDULE
    """

    renderer_classes = [JSONRenderer, TemplateHTMLRenderer]
    template_name = "weekly_schedule.html"
    permission_classes = [IsAdminOrReadOnly]

    def get(self, request, week_id, format=None):
        week = get_object_or_404(Week, id=week_id)
        serializer = WeekScheduleSerializer(week)

        if request.accepted_renderer.format == "html":
            return Response(
                {"week": serializer.data},
                template_name=self.template_name
            )

        return Response(
            {"status": "success", "data": serializer.data},
            status=status.HTTP_200_OK
        )



from django.db import models
from django.db.models import Prefetch

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated

from .models import Week, ScheduleSlot
from .serializers import WeekScheduleSerializer



class TimetableAPIView(APIView):
    """
    TIMETABLE API

    ADMIN:
        - View all weeks
        - Filter by trainer_id
        - Filter by student_id

    TRAINER:
        - View only own timetable

    STUDENT:
        - View only enrolled course timetable
    """

    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        role = getattr(user, "role", None)

        # Base queryset
        weeks = Week.objects.filter(is_active=True).order_by("start_date")

        # ===============================
        # ADMIN
        # ===============================
        if role == "ADMIN":
            trainer_id = request.query_params.get("trainer_id")
            student_id = request.query_params.get("student_id")

            slot_qs = ScheduleSlot.objects.all()

            # Filter by trainer
            if trainer_id:
                slot_qs = slot_qs.filter(trainer_id=trainer_id)

            # Filter by student
            if student_id:
                course_ids = Enrollment.objects.filter(
                    student_id=student_id,
                    status="ACTIVE",
                    is_active=True
                ).values_list("course_id", flat=True)

                slot_qs = slot_qs.filter(
                    module__course_id__in=course_ids
                )

            weeks = weeks.prefetch_related(
                Prefetch("slots", queryset=slot_qs)
            )

        # ===============================
        # TRAINER
        # ===============================
        elif role == "TRAINER":
            try:
                trainer = TrainerProfile.objects.get(user=user)
            except TrainerProfile.DoesNotExist:
                return Response(
                    {"detail": "Trainer profile not found"},
                    status=400
                )

            weeks = weeks.prefetch_related(
                Prefetch(
                    "slots",
                    queryset=ScheduleSlot.objects.filter(trainer=trainer)
                )
            )

        # ===============================
        # STUDENT
        # ===============================
        elif role == "STUDENT":
            course_ids = Enrollment.objects.filter(
                student=user,
                status="ACTIVE",
                is_active=True
            ).values_list("course_id", flat=True)

            weeks = weeks.prefetch_related(
                Prefetch(
                    "slots",
                    queryset=ScheduleSlot.objects.filter(
                        module__course_id__in=course_ids
                    )
                )
            )

        else:
            return Response(
                {"detail": "Invalid role"},
                status=403
            )

        serializer = WeekScheduleSerializer(weeks, many=True)

        return Response({
            "status": "success",
            "role": role,
            "filters": request.query_params,
            "data": serializer.data
        })


# from reportlab.lib.pagesizes import A4
# from reportlab.pdfgen import canvas
# from django.http import HttpResponse


# class TimetablePDFExportAPIView(APIView):
#     """
#     Export timetable as PDF
#     ADMIN   → all / filtered timetable
#     TRAINER → own timetable
#     STUDENT → enrolled timetable
#     """

#     permission_classes = [IsAuthenticated]

#     def get(self, request):
#         user = request.user
#         role = getattr(user, "role", None)

#         weeks = Week.objects.filter(is_active=True).order_by("start_date")

#         # ================= ADMIN =================
#         if role == "ADMIN":
#             weeks = weeks.prefetch_related("slots")

#         # ================= TRAINER =================
#         elif role == "TRAINER":
#             trainer = TrainerProfile.objects.get(user=user)
#             weeks = weeks.prefetch_related(
#                 Prefetch(
#                     "slots",
#                     queryset=ScheduleSlot.objects.filter(trainer=trainer)
#                 )
#             )

#         # ================= STUDENT =================
#         elif role == "STUDENT":
#             course_ids = Enrollment.objects.filter(
#                 student=user,
#                 status="ACTIVE",
#                 is_active=True
#             ).values_list("course_id", flat=True)

#             weeks = weeks.prefetch_related(
#                 Prefetch(
#                     "slots",
#                     queryset=ScheduleSlot.objects.filter(
#                         module__course_id__in=course_ids
#                     )
#                 )
#             )

#         else:
#             return Response({"detail": "Invalid role"}, status=403)

#         # ================= PDF GENERATION =================
#         response = HttpResponse(content_type="application/pdf")
#         response["Content-Disposition"] = 'attachment; filename="timetable.pdf"'

#         pdf = canvas.Canvas(response, pagesize=A4)
#         width, height = A4

#         y = height - 40
#         pdf.setFont("Helvetica-Bold", 14)
#         pdf.drawString(40, y, f"TIMETABLE ({role})")
#         y -= 30

#         pdf.setFont("Helvetica", 10)

#         for week in weeks:
#             pdf.drawString(40, y, f"Week: {week.week_name}")
#             y -= 20

#             for slot in week.slots.all():
#                 line = (
#                     f"{slot.day} | "
#                     f"{slot.start_time}-{slot.end_time} | "
#                     f"{slot.module.name} | "
#                     f"{slot.trainer.identity_user.first_name()}"
#                 )
#                 pdf.drawString(60, y, line)
#                 y -= 15

#                 if y < 60:
#                     pdf.showPage()
#                     pdf.setFont("Helvetica", 10)
#                     y = height - 40

#             y -= 10

#         pdf.showPage()
#         pdf.save()
#         return response
