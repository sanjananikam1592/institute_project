from rest_framework.permissions import BasePermission, SAFE_METHODS

class IsAdminOrReadOnly(BasePermission):
    """
    Permissions:

    - Superuser → full CRUD
    - Admin group (is_staff=True & in 'Admin' group) → full CRUD
    - Trainer & Student → read-only
    """

    def has_permission(self, request, view):
        # Block unauthenticated users completely
        if not request.user or not request.user.is_authenticated:
            return False

        # READ permissions for all authenticated users
        if request.method in SAFE_METHODS:
            return True

        # WRITE permissions
        user = request.user

        # Superusers can do everything
        if user.is_superuser:
            return True

        # Admin group members with staff status can do everything
        if user.is_staff and user.groups.filter(name="Admin").exists():
            return True

        # Everyone else (Trainer/Student) → read-only
        return False
