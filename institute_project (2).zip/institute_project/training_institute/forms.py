from django import forms
from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError

from .models import AdminProfile, TrainerProfile, StudentProfile,Course,Module,Enrollment


User = get_user_model()


class UserRegistrationForm(forms.ModelForm):
    password = forms.CharField(
        widget=forms.PasswordInput(attrs={'placeholder': 'Password'}),
        min_length=8
    )
    confirm_password = forms.CharField(
        widget=forms.PasswordInput(attrs={'placeholder': 'Confirm Password'}),
        min_length=8
    )

    class Meta:
        model = User
        fields = [
            'username',
            'email',
            'first_name',
            'last_name',
            'country_code',
            'mobile_number',
            'role',
        ]

    def clean(self):
        cleaned_data = super().clean()

        password = cleaned_data.get('password')
        confirm_password = cleaned_data.get('confirm_password')

        if password and confirm_password and password != confirm_password:
            raise ValidationError("Passwords do not match")

        return cleaned_data

    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data['password'])
        user.is_active = True
        user.is_approved = False  # Admin must approve
        if commit:
            user.save()
        return user


class AdminProfileForm(forms.ModelForm):

    class Meta:
        model = AdminProfile
        fields = [
            'employee_id',
            'department',
            'designation',
            'office_address',
            'joining_date',
        ]

    def clean(self):
        cleaned_data = super().clean()

        user = self.instance.user
        if user.role != 'ADMIN':
            raise ValidationError("User role must be ADMIN")

        return cleaned_data


class TrainerProfileForm(forms.ModelForm):

    class Meta:
        model = TrainerProfile
        fields = [
            'trainer_code',
            'specialization',
            'qualification',
            'experience_years',
            'joining_date',
        ]

    def clean(self):
        cleaned_data = super().clean()

        user = self.instance.user
        if user.role != 'TRAINER':
            raise ValidationError("User role must be TRAINER")

        return cleaned_data


class StudentProfileForm(forms.ModelForm):

    class Meta:
        model = StudentProfile
        fields = [
            'enrollment_number',
            'course_name',
            'batch_year',
            'date_of_birth',
            'address',
            'admission_date',
        ]

    def clean(self):
        cleaned_data = super().clean()

        user = self.instance.user
        if user.role != 'STUDENT':
            raise ValidationError("User role must be STUDENT")

        return cleaned_data




######################################################################

class CourseForm(forms.ModelForm):
    class Meta:
        model = Course
        fields = [
            "course_code",
            "course_name",
            "description",
            "duration_weeks",
            "status",
            "is_active",
        ]

        widgets = {
            "course_code": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "Enter Course Code (e.g. PY-FS)"
            }),
            "course_name": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "Enter Course Name"
            }),
            "description": forms.Textarea(attrs={
                "class": "form-control",
                "rows": 3
            }),
            "duration_weeks": forms.NumberInput(attrs={
                "class": "form-control",
                "min": 1
            }),
            "status": forms.Select(attrs={
                "class": "form-control"
            }),
            "is_active": forms.CheckboxInput(attrs={
                "class": "form-check-input"
            }),
        }

    # 🔐 Validation
    def clean_course_code(self):
        code = self.cleaned_data["course_code"].upper()
        if Course.objects.filter(course_code=code).exclude(pk=self.instance.pk).exists():
            raise forms.ValidationError("Course code already exists.")
        return code


class ModuleForm(forms.ModelForm):
    class Meta:
        model = Module
        fields = [
            "module_code",
            "module_name",
            "sequence_no",
            "duration_hours",
            "description",
            "status",
            "is_active",
        ]

        widgets = {
            "module_code": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "Enter Module Code (e.g. PY-01)"
            }),
            "module_name": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "Enter Module Name"
            }),
            "sequence_no": forms.NumberInput(attrs={
                "class": "form-control",
                "min": 1
            }),
            "duration_hours": forms.NumberInput(attrs={
                "class": "form-control",
                "min": 1
            }),
            "description": forms.Textarea(attrs={
                "class": "form-control",
                "rows": 3
            }),
            "status": forms.Select(attrs={
                "class": "form-control"
            }),
            "is_active": forms.CheckboxInput(attrs={
                "class": "form-check-input"
            }),
        }

    # 🔐 Validation
    def clean_module_code(self):
        code = self.cleaned_data["module_code"].upper()
        course = self.instance.course if self.instance.pk else self.initial.get("course")

        if course and Module.objects.filter(
            module_code=code, course=course
        ).exclude(pk=self.instance.pk).exists():
            raise forms.ValidationError(
                "This module code already exists for the selected course."
            )

        return code


from django import forms
from django.core.exceptions import ValidationError
from .models import Enrollment

class EnrollmentForm(forms.ModelForm):
    class Meta:
        model = Enrollment
        fields = [
            "student",
            "course",
            "status",
            "is_active",
            "grade",
            "created_by",
            "updated_by",
        ]
        widgets = {
            "status": forms.Select(attrs={"class": "form-control"}),
            "student": forms.Select(attrs={"class": "form-control"}),
            "course": forms.Select(attrs={"class": "form-control"}),
            "is_active": forms.CheckboxInput(attrs={"class": "form-check-input"}),
            "grade": forms.NumberInput(attrs={"class": "form-control", "step": "0.01", "min": 0, "max": 100}),
            "created_by": forms.Select(attrs={"class": "form-control"}),
            "updated_by": forms.Select(attrs={"class": "form-control"}),
        }

    def clean_grade(self):
        grade = self.cleaned_data.get("grade")
        if grade is not None and (grade < 0 or grade > 100):
            raise ValidationError("Grade must be between 0 and 100.")
        return grade

    def clean(self):
        cleaned_data = super().clean()
        status = cleaned_data.get("status")
        is_active = cleaned_data.get("is_active")

        if status == "COMPLETED" and not is_active:
            raise ValidationError("Completed enrollments must be active.")


from django import forms
from django.core.exceptions import ValidationError

from .models import Week, ScheduleSlot
from courses.models import Module
from identity.models import TrainerProfile


class WeekForm(forms.ModelForm):
    class Meta:
        model = Week
        fields = [
            "week_name",
            "start_date",
            "end_date",
            "is_active",
        ]
        widgets = {
            "week_name": forms.TextInput(
                attrs={
                    "class": "form-control",
                    "placeholder": "Week 1"
                }
            ),
            "start_date": forms.DateInput(
                attrs={
                    "type": "date",
                    "class": "form-control"
                }
            ),
            "end_date": forms.DateInput(
                attrs={
                    "type": "date",
                    "class": "form-control"
                }
            ),
            "is_active": forms.CheckboxInput(
                attrs={"class": "form-check-input"}
            ),
        }

    def clean(self):
        cleaned_data = super().clean()
        start_date = cleaned_data.get("start_date")
        end_date = cleaned_data.get("end_date")

        if start_date and end_date and start_date >= end_date:
            raise ValidationError(
                "Start date must be before end date"
            )

        return cleaned_data


class ScheduleSlotForm(forms.ModelForm):
    class Meta:
        model = ScheduleSlot
        fields = [
            "week",
            "day",
            "start_time",
            "end_time",
            "trainer",
            "module",
            "status",
            "remarks",
        ]
        widgets = {
            "week": forms.Select(
                attrs={"class": "form-control"}
            ),
            "day": forms.Select(
                attrs={"class": "form-control"}
            ),
            "start_time": forms.TimeInput(
                attrs={
                    "type": "time",
                    "class": "form-control"
                }
            ),
            "end_time": forms.TimeInput(
                attrs={
                    "type": "time",
                    "class": "form-control"
                }
            ),
            "trainer": forms.Select(
                attrs={"class": "form-control"}
            ),
            "module": forms.Select(
                attrs={"class": "form-control"}
            ),
            "status": forms.Select(
                attrs={"class": "form-control"}
            ),
            "remarks": forms.TextInput(
                attrs={
                    "class": "form-control",
                    "placeholder": "Optional remarks"
                }
            ),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # Show only ACTIVE modules
        self.fields["module"].queryset = Module.objects.filter(
            status="ACTIVE",
            is_active=True
        )

        # Show only approved trainers (if approval logic exists)
        self.fields["trainer"].queryset = TrainerProfile.objects.all()

    def clean(self):
        cleaned_data = super().clean()

        start_time = cleaned_data.get("start_time")
        end_time = cleaned_data.get("end_time")
        status = cleaned_data.get("status")
        trainer = cleaned_data.get("trainer")
        module = cleaned_data.get("module")

        # Time validation
        if start_time and end_time and start_time >= end_time:
            raise ValidationError(
                "Start time must be before end time"
            )

        # Allocation validation
        if status == "ALLOCATED":
            if not trainer or not module:
                raise ValidationError(
                    "Trainer and Module are required when slot is allocated"
                )

        return cleaned_data
