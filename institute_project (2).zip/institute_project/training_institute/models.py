from django.db import models
from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin, BaseUserManager
from django.core.validators import RegexValidator, MinValueValidator
from django.utils import timezone
from django.conf import settings
import uuid
from django.db import models
from django.conf import settings
from django.core.exceptions import ValidationError


# =====================================================
# USER MANAGER
# =====================================================
class UserManager(BaseUserManager):
    def create_user(
        self, username, email, first_name, last_name,
        country_code, mobile_number, role, password=None
    ):
        if not username:
            raise ValueError("Username required")
        if not email:
            raise ValueError("Email required")

        email = self.normalize_email(email)

        user = self.model(
            username=username,
            email=email,
            first_name=first_name,
            last_name=last_name,
            country_code=country_code,
            mobile_number=mobile_number,
            role=role
        )
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(
        self, username, email, first_name, last_name,
        country_code, mobile_number, password
    ):
        user = self.create_user(
            username=username,
            email=email,
            first_name=first_name,
            last_name=last_name,
            country_code=country_code,
            mobile_number=mobile_number,
            role='ADMIN',
            password=password
        )
        user.is_staff = True
        user.is_superuser = True
        user.is_active = True
        user.is_approved = True
        user.save()
        return user


# =====================================================
# USER MODEL (identity_user)
# =====================================================
class User(AbstractBaseUser, PermissionsMixin):

    ROLE_CHOICES = (
        ('ADMIN', 'Admin'),
        ('TRAINER', 'Trainer'),
        ('STUDENT', 'Student'),
    )

    username = models.CharField(max_length=150, unique=True)
    first_name = models.CharField(max_length=150)
    last_name = models.CharField(max_length=150)

    email = models.EmailField(unique=True)

    country_code = models.CharField(
        max_length=5,
        validators=[RegexValidator(regex=r'^\+[0-9]{1,4}$')],
        null=True,
        blank=True
    )

    mobile_number = models.CharField(
        max_length=10,
        validators=[RegexValidator(regex=r'^[6-9][0-9]{9}$')],
        null=True,
        blank=True
    )

    role = models.CharField(max_length=20, choices=ROLE_CHOICES)

    is_approved = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)
    is_superuser = models.BooleanField(default=False)

    last_login = models.DateTimeField(null=True, blank=True)
    date_joined = models.DateTimeField(auto_now_add=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    objects = UserManager()

    USERNAME_FIELD = 'username'
    REQUIRED_FIELDS = [
        'email', 'first_name', 'last_name',
        'country_code', 'mobile_number'
    ]

    class Meta:
        db_table = 'identity_user'

    def __str__(self):
        return f"{self.username} ({self.role})"


# =====================================================
# ADMIN PROFILE
# =====================================================
class AdminProfile(models.Model):
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='admin_profile'
    )
    employee_id = models.CharField(max_length=20, unique=True)
    department = models.CharField(max_length=100)
    designation = models.CharField(max_length=100)
    office_address = models.TextField()
    joining_date = models.DateField(default=timezone.now)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'identity_adminprofile'

    def save(self, *args, **kwargs):
        if self.user.role != 'ADMIN':
            raise ValueError("User role must be ADMIN")
        super().save(*args, **kwargs)


# =====================================================
# TRAINER PROFILE
# =====================================================
# class TrainerProfile(models.Model):
#     user = models.OneToOneField(
#         settings.AUTH_USER_MODEL,
#         on_delete=models.CASCADE,
#         related_name='trainer_profile'
#     )
#     trainer_code = models.CharField(max_length=20, unique=True)
#     specialization = models.CharField(max_length=200)
#     qualification = models.CharField(max_length=200)
#     experience_years = models.PositiveIntegerField(
#         validators=[MinValueValidator(0)]
#     )
#     joining_date = models.DateField(default=timezone.now)

#     approved_by = models.ForeignKey(
#         settings.AUTH_USER_MODEL,
#         on_delete=models.SET_NULL,
#         null=True,
#         blank=True,
#         related_name='approved_trainers'
#     )
#     approved_at = models.DateTimeField(null=True, blank=True)

#     created_at = models.DateTimeField(auto_now_add=True)
#     updated_at = models.DateTimeField(auto_now=True)

#     class Meta:
#         db_table = 'identity_trainerprofile'

#     def save(self, *args, **kwargs):
        if self.user.role != 'TRAINER':
            raise ValueError("User role must be TRAINER")
        super().save(*args, **kwargs)


class TrainerProfile(models.Model):
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='trainer_profile'
    )
    trainer_code = models.CharField(max_length=20, unique=True)
    specialization = models.CharField(max_length=200)
    qualification = models.CharField(max_length=200)
    experience_years = models.PositiveIntegerField(
        validators=[MinValueValidator(0)]
    )
    joining_date = models.DateField(default=timezone.now)

    approved_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='approved_trainers'
    )
    approved_at = models.DateTimeField(null=True, blank=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'identity_trainerprofile'

    def save(self, *args, **kwargs):
        if self.user.role != 'TRAINER':
            raise ValueError("User role must be TRAINER")
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.user.username} ({self.trainer_code})"

# =====================================================
# STUDENT PROFILE
# =====================================================
# class StudentProfile(models.Model):
#     user = models.OneToOneField(
#         settings.AUTH_USER_MODEL,
#         on_delete=models.CASCADE,
#         related_name='student_profile'
#     )
#     enrollment_number = models.CharField(max_length=20, unique=True)
#     course_name = models.CharField(max_length=200)
#     batch_year = models.PositiveIntegerField()
#     date_of_birth = models.DateField()
#     address = models.TextField()
#     admission_date = models.DateField(default=timezone.now)

#     approved_by = models.ForeignKey(
#         settings.AUTH_USER_MODEL,
#         on_delete=models.SET_NULL,
#         null=True,
#         blank=True,
#         related_name='approved_students'
#     )
#     approved_at = models.DateTimeField(null=True, blank=True)

#     created_at = models.DateTimeField(auto_now_add=True)
#     updated_at = models.DateTimeField(auto_now=True)

#     class Meta:
#         db_table = 'identity_studentprofile'

#     def save(self, *args, **kwargs):
#         if self.user.role != 'STUDENT':
#             raise ValueError("User role must be STUDENT")
#         super().save(*args, **kwargs)



class StudentProfile(models.Model):
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='student_profile'
    )
    enrollment_number = models.CharField(max_length=20, unique=True)
    course_name = models.CharField(max_length=200)
    batch_year = models.PositiveIntegerField()
    date_of_birth = models.DateField()
    address = models.TextField()
    admission_date = models.DateField(default=timezone.now)

    approved_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='approved_students'
    )
    approved_at = models.DateTimeField(null=True, blank=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'identity_studentprofile'

    def save(self, *args, **kwargs):
        if self.user.role != 'STUDENT':
            raise ValueError("User role must be STUDENT")
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.user.username} ({self.enrollment_number})"



###############################################################################################


class Course(models.Model):
    STATUS_CHOICES = [
        ("DRAFT", "Draft"),
        ("ACTIVE", "Active"),
        ("INACTIVE", "Inactive"),
        ("ARCHIVED", "Archived"),
    ]

    course_code = models.CharField(
        max_length=20,
        unique=True,
        db_index=True
    )
    course_name = models.CharField(max_length=200)
    description = models.TextField(blank=True)

    duration_weeks = models.PositiveIntegerField(
        help_text="Total course duration in weeks"
    )
    total_modules = models.PositiveIntegerField(default=0)

    status = models.CharField(
        max_length=10,
        choices=STATUS_CHOICES,
        default="DRAFT"
    )

    is_active = models.BooleanField(default=True)

    created_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        related_name="created_courses"
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["course_name"]
        verbose_name = "Course"
        verbose_name_plural = "Courses"

    def __str__(self):
        return f"{self.course_code} - {self.course_name}"


# class Module(models.Model):
#     STATUS_CHOICES = [
#         ("DRAFT", "Draft"),
#         ("ACTIVE", "Active"),
#         ("COMPLETED", "Completed"),
#     ]

#     module_code = models.CharField(max_length=20)
#     module_name = models.CharField(max_length=200)

#     course = models.ForeignKey(
#         Course,
#         on_delete=models.CASCADE,
#         related_name="modules"
#     )

#     sequence_no = models.PositiveIntegerField(
#         help_text="Module order within the course"
#     )

#     duration_hours = models.PositiveIntegerField(
#         help_text="Total hours required to complete this module"
#     )

#     description = models.TextField(blank=True)

#     status = models.CharField(
#         max_length=10,
#         choices=STATUS_CHOICES,
#         default="DRAFT"
#     )

#     is_active = models.BooleanField(default=True)

#     created_by = models.ForeignKey(
#         User,
#         on_delete=models.SET_NULL,
#         null=True,
#         related_name="created_modules"
#     )
#     created_at = models.DateTimeField(auto_now_add=True)
#     updated_at = models.DateTimeField(auto_now=True)

#     class Meta:
#         unique_together = ("module_code", "course")
#         ordering = ["sequence_no"]
#         verbose_name = "Module"
#         verbose_name_plural = "Modules"

#     def __str__(self):
#         return f"{self.course.course_code} | {self.module_code} - {self.module_name}"


# =====================================================
# Module model fix (add 'name' property)
# =====================================================
class Module(models.Model):
    STATUS_CHOICES = [
        ("DRAFT", "Draft"),
        ("ACTIVE", "Active"),
        ("COMPLETED", "Completed"),
    ]

    module_code = models.CharField(max_length=20)
    module_name = models.CharField(max_length=200)

    course = models.ForeignKey(
        Course,
        on_delete=models.CASCADE,
        related_name="modules"
    )

    sequence_no = models.PositiveIntegerField(
        help_text="Module order within the course"
    )

    duration_hours = models.PositiveIntegerField(
        help_text="Total hours required to complete this module"
    )

    description = models.TextField(blank=True)

    status = models.CharField(
        max_length=10,
        choices=STATUS_CHOICES,
        default="DRAFT"
    )

    is_active = models.BooleanField(default=True)

    created_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        related_name="created_modules"
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ("module_code", "course")
        ordering = ["sequence_no"]
        verbose_name = "Module"
        verbose_name_plural = "Modules"

    def __str__(self):
        return f"{self.course.course_code} | {self.module_code} - {self.module_name}"

    # Add this property to fix PDF error
    @property
    def name(self):
        return self.module_name




class Enrollment(models.Model):
    """Model to track student enrollment in courses."""

    STATUS_CHOICES = [
        ("PENDING", "Pending"),
        ("ACTIVE", "Active"),
        ("COMPLETED", "Completed"),
        ("CANCELLED", "Cancelled"),
    ]

    id = models.UUIDField(
        primary_key=True,
        default=uuid.uuid4,
        editable=False,
        help_text="Unique enrollment ID"
    )
    student = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name="enrollments",
        help_text="Student enrolled in the course"
    )
    course = models.ForeignKey(
        "training_institute.Course",  # Correct: "app_label.ModelName"
        on_delete=models.CASCADE,
        related_name="enrollments"
    )


    status = models.CharField(
        max_length=10,
        choices=STATUS_CHOICES,
        default="PENDING",
        help_text="Current enrollment status"
    )
    enrolled_at = models.DateTimeField(
        auto_now_add=True,
        help_text="Enrollment creation timestamp"
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        help_text="Last update timestamp"
    )
    is_active = models.BooleanField(
        default=True,
        help_text="Soft delete flag for enrollment"
    )
    grade = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        null=True,
        blank=True,
        help_text="Optional grade (0-100)"
    )
    created_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="created_enrollments",
        help_text="User who created the enrollment record"
    )
    updated_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="updated_enrollments",
        help_text="User who last updated the enrollment record"
    )

    class Meta:
        unique_together = ("student", "course")  # Same as UNIQUE(student_id, course_id)
        ordering = ["-enrolled_at"]
        indexes = [
            models.Index(fields=["student"]),
            models.Index(fields=["course"]),
            models.Index(fields=["status"]),
        ]
        verbose_name = "Enrollment"
        verbose_name_plural = "Enrollments"

    def clean(self):
        """Custom validation similar to PostgreSQL trigger."""
        # Cannot mark COMPLETED if inactive
        if self.status == "COMPLETED" and not self.is_active:
            raise ValidationError("Completed enrollments must be active.")
        # Ensure grade is between 0 and 100
        if self.grade is not None and (self.grade < 0 or self.grade > 100):
            raise ValidationError("Grade must be between 0 and 100.")

    def __str__(self):
        return f"{self.student} → {self.course} | {self.status}"



class Week(models.Model):
    week_name = models.CharField(
        max_length=50,
        unique=True,                 # Week duplication avoid
        help_text="Example: Week 1, Week 2"
    )
    start_date = models.DateField()
    end_date = models.DateField()

    is_active = models.BooleanField(default=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["start_date"]
        verbose_name = "Week"
        verbose_name_plural = "Weeks"

    def clean(self):
        if self.start_date >= self.end_date:
            raise ValidationError("Start date must be before end date")

    def __str__(self):
        return f"{self.week_name} ({self.start_date} - {self.end_date})"



class ScheduleSlot(models.Model):
    DAY_CHOICES = [
        ("MON", "Monday"),
        ("TUE", "Tuesday"),
        ("WED", "Wednesday"),
        ("THU", "Thursday"),
        ("FRI", "Friday"),
        ("SAT", "Saturday"),
    ]

    STATUS_CHOICES = [
        ("FREE", "Free"),
        ("ALLOCATED", "Allocated"),
        ("COMPLETED", "Completed"),
        ("CANCELLED", "Cancelled"),
    ]

    week = models.ForeignKey(
        Week,
        on_delete=models.CASCADE,
        related_name="slots"
    )

    day = models.CharField(
        max_length=3,
        choices=DAY_CHOICES
    )

    start_time = models.TimeField()
    end_time = models.TimeField()

    trainer = models.ForeignKey(
        TrainerProfile,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="schedule_slots"
    )

    module = models.ForeignKey(
        Module,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="schedule_slots"
    )

    status = models.CharField(
        max_length=10,
        choices=STATUS_CHOICES,
        default="FREE"
    )

    remarks = models.CharField(
        max_length=255,
        blank=True,
        help_text="Optional remarks for this slot"
    )

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = (
            "week",
            "day",
            "start_time",
        )
        ordering = ["day", "start_time"]
        verbose_name = "Schedule Slot"
        verbose_name_plural = "Schedule Slots"

    def clean(self):
        # Time validation
        if self.start_time >= self.end_time:
            raise ValidationError("Start time must be before end time")

        # If allocated, both trainer & module must be present
        if self.status == "ALLOCATED":
            if not self.trainer or not self.module:
                raise ValidationError(
                    "Trainer and Module are required for allocated slot"
                )

        # Only ACTIVE module allowed
        if self.module and self.module.status != "ACTIVE":
            raise ValidationError(
                "Only ACTIVE modules can be scheduled"
            )

    def save(self, *args, **kwargs):
        self.full_clean()
        super().save(*args, **kwargs)

    def __str__(self):
        return (
            f"{self.week.week_name} | "
            f"{self.get_day_display()} "
            f"{self.start_time}-{self.end_time}"
        )

